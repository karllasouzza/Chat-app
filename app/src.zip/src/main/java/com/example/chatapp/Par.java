package com.example.chatapp;

public class Par {
    private String nome;
    private String valor;

    public Par() {
        super();
    }

    public Par(String nome, String valor) {
        super();
        this.nome = nome;
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public String getValor() {
        return valor;
    }

}

