let login = Ponte.getLogin();

if (!login) {
  location.href = "./index.html";
} else {
}
